import React from 'react';
import MainSection from '../containers/MainSection';

export default function App() {
  return (
    <div className="container">
      <MainSection />
    </div>
  );
}
