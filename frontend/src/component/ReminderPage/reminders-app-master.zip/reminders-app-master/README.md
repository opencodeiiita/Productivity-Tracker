[![Build Status](https://travis-ci.org/zv3/reminders-app.svg?branch=master)](https://travis-ci.org/zv3/reminders-app)

Simple reminder application built with React and Redux.

![demo](https://dzv3.s3.amazonaws.com/captures/Kapture%202019-02-04%20at%2021.39.07.gif)
